<?php
class Join{
    private $categories = array("Dry Clean", "Mechanics",
        "Car Washing", "Hospital", "Clinic", "Pharmacy",
        "Supermarket", "Vegtables Store", "Food Delivery",
        "Restaurants", "Others");
    function checkCategory($cat) {
        $currentCat = null;
        $size=sizeof($this->categories);
        for ($i = 0; $i <$size; $i++) {
            if ($cat == $this->categories[$i]) {
                $currentCat = $this->categories[$i];
            }
        }
        $currentCat= strtolower($currentCat);
        $currentCat=str_replace(' ', '', $currentCat);
        return $currentCat;
    }
}
