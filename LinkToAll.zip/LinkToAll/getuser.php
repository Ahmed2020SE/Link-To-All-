<!DOCTYPE html>
<html>
    <head><title>getuser</title></head>
    <body>
<?php
include './Config.php';
$name=$_GET['name']; 
$connect=new Config();
$con=$connect->connectTo();
$sql="SELECT * FROM user WHERE name = '".$name."'";
$result = mysqli_query($con,$sql);
echo "<table class='table table-hover'>
<tr>
<th>Name</th>
<th>Address</th>
<th>Mobile</th>
<th>City</th>
<th>State</th>
<th>Country</th>
<th>Post Code</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['address'] . "</td>";
    echo "<td>" . $row['mobile'] . "</td>";
    echo "<td>" . $row['city'] . "</td>";
    echo "<td>" . $row['state'] . "</td>";
    echo "<td>" . $row['country'] . "</td>";
    echo "<td>" . $row['postcode'] . "</td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($con);

?>
    </body>
</html>