<?php
include './Config.php';
$cat=$_POST['category'];
$cat= strtolower($cat);
$cat=str_replace(' ', '', $cat);
$connect1=new Config();
$conn=$connect1->connectTo();
$sql = "Insert into $cat (name, address, mobile, city,state,country,postcode) values
('$_POST[name]','$_POST[address]','$_POST[mobile]','$_POST[city]','$_POST[state]','$_POST[country]','$_POST[postcode]')";
        $sql2="Insert into alltables (name, address, mobile, city,state,country,postcode) values
('$_POST[name]','$_POST[address]','$_POST[mobile]','$_POST[city]','$_POST[state]','$_POST[country]','$_POST[postcode]')";
if(isset($_POST['submit'])){
    $joinname=$_POST['name'];
    $joinaddress=$_POST['address'];
    $joinmobile=$_POST['mobile'];
    $joincity=$_POST['city'];
    $joinstate=$_POST['state'];
    $joinpost=$_POST['postcode'];
    $joincountry=$_POST['country'];
    
    $errorEmpty=false;
    $errorMobile=false;
    if(empty($joinname)||empty($joinaddress)||empty($joinmobile)||empty($joincity)
            ||empty($joinstate)||empty($joinpost)||empty($joincountry)){
        echo "<span class='alert alert-danger'>Fill in all fields!</span> ";
        $errorEmpty=true;
    }
    elseif(!preg_match('/^[0-9]{11}+$/', $joinmobile)){
        echo "<span class='alert alert-danger'>Enter valid mobile number!</span> ";
        $errorMobile=true;
    }
    else if(!mysqli_query($conn, $sql)){
    echo "<span class='alert alert-danger'>Bussiness mobile is already exist!</span>";
}
    else
    {
        echo "<span class='alert alert-success'>Thank You For joining us.</span> ";
        
    }
    mysqli_close($conn);
}else{
    echo "<span class='alert alert-danger'>There was an error try agin later.</span>";
}
 ?>
<script>
    $("#join-name,#join-address,#join-mobile,join-city,#join-state,#join-postcode,#join-country").removeClass("input-error");
var errorEmpty="<?php echo $errorEmpty;?>";
var errorMobile="<?php echo $errorMobile;?>";
if(errorEmpty==true){
    $("#join-name,#join-address,#join-mobile,#join-city,#join-state,#join-postcode,#join-country").addClass("input-error");
}
if(errorMobile==true){
    $("#join-mobile").addClass("input-error");
}
if(errorEmpty==false && errorMobile==false){
    $("#join-name,#join-address,#join-mobile,#join-city,#join-state,#join-postcode,#join-country").val("");
}
</script>