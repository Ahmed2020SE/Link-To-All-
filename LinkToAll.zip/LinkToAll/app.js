$(document).ready(function () {
    $('.dropdown-submenu a.test').on("click", function (e) {
        $(this).next('ul').toggle();
        e.stopPropagation();
        e.preventDefault();
    });
});
$('.navbar .dropdown').hover(function () {
    $(this).find('.dropdown-menu').first().stop(true, true).slideDown(150);
}, function () {
    $(this).find('.dropdown-menu').first().stop(true, true).slideUp(105)
});
function validjoinform() {
    var name = document.forms["joinform"]["name"].value;
    var address = document.forms["joinform"]["address"].value;
    var mobile = document.forms["joinform"]["mobile"].value;
    var city = document.forms["joinform"]["city"].value;
    var state = document.forms["joinform"]["state"].value;
    var postcode = document.forms["joinform"]["postcode"].value;
    if (name === null || name === "") {
        alert("Please Enter Your Bussiness Name");
        return false;
    }
    if (mobile !== "/^\d{10}$/" || mobile === null) {} else {
        alert("Please Enter You Bussiness Mobile");
        return false;
    }
}