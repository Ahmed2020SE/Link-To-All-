<?php
class Config{
private $host = "localhost";
private $Username = "root";
private $Password = "";
private $Database = "project"; 

public function connectTo(){
    $con = mysqli_connect($this->host, $this->Username, $this->Password, $this->Database) or die("Couldn't connect to Database");
    return $con;
}
} 


     
    


